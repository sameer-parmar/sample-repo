from django.apps import AppConfig


class PlacementStoriesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'placement_stories'
