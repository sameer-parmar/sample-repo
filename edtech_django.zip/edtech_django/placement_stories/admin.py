from django.contrib import admin

# Register your models here.
from  placement_stories import models
admin.site.register(models.PlacementStories)